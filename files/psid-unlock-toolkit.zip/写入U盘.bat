@echo off
setlocal
title PSID Toolkit - Copy to USB
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0copy_to_usb.ps1"
if errorlevel 1 (
  echo.
  echo Script ended with a problem. Read the message above.
  echo Alternative: right-click copy_to_usb.ps1 - Run with PowerShell
  echo.
  pause
  exit /b 1
)
echo.
echo Finished. Press any key to close this window.
pause >nul
exit /b 0
