@echo off
setlocal EnableExtensions EnableDelayedExpansion
title PSID Revert - WinPE / Safe Mode edition
cd /d "%~dp0"

echo ============================================================
echo  PSID Revert - WinPE / Safe Mode edition
echo  Pure cmd: no PowerShell, no UAC, no Server service needed.
echo  English output: some PE builds have no CJK font.
echo  This DESTROYS the encryption key and ALL data on the disk.
echo ============================================================
echo.

set "CLI=%~dp0sedutil-cli.exe"
if not exist "%CLI%" (
  echo [ERROR] sedutil-cli.exe not found next to this script.
  echo Copy the WHOLE PSID_Revert folder, not just the .bat file.
  goto DONE
)
if not exist "%~dp0MSVCP140.dll" (
  echo [WARN] MSVCP140.dll is missing here.
  echo        On WinPE the tool cannot start without it.
)
if not exist "%~dp0VCRUNTIME140.dll" (
  echo [WARN] VCRUNTIME140.dll is missing here.
)

if not defined TEMP set "TEMP=%~dp0"
set "SCANFILE=%TEMP%\psid_scan.txt"
set "CAND_FILE=%TEMP%\psid_cands.txt"
set "PSID_FILE=%TEMP%\psid_line.txt"

if defined PSID_SCAN_FILE (
  set "SCANFILE=%PSID_SCAN_FILE%"
  echo [TEST MODE] Using scan file: !SCANFILE!
) else (
  echo [1/5] Scanning for Opal disks ...
  "%CLI%" --scan > "!SCANFILE!" 2>&1
)
echo.
type "!SCANFILE!"
echo.

findstr /i /c:"proper authority" /c:"Try running as Administrator" "!SCANFILE!" >nul
if not errorlevel 1 (
  echo [ERROR] No raw-disk access - an elevated token is required.
  echo   In WinPE you are already SYSTEM: the PE likely lacks NVMe
  echo   drivers, use a Win10/11 64-bit PE.
  echo   In Windows SAFE MODE: UAC elevation is often unavailable and
  echo   net session is NOT a valid admin test - Server service is off.
  echo   Log in with the built-in Administrator account, or boot
  echo   WinPE / Linux from the USB instead.
  goto DONE
)

echo [2/5] Picking the target disk ...
findstr /r /c:"PhysicalDrive[0-9]" "!SCANFILE!" > "!CAND_FILE!" 2>nul
set "CNT=0"
set "CANDS="
for /f "usebackq delims=" %%L in ("!CAND_FILE!") do (
  set "LINE=%%L"
  set "REST=!LINE:*PhysicalDrive=!"
  for /f "tokens=1" %%N in ("!REST!") do set "NUM=%%N"
  echo !NUM!| findstr /r "^[0-9][0-9]*$" >nul
  if not errorlevel 1 (
    set /a CNT+=1
    set "CANDS=!CANDS! !NUM!"
  )
)

if "!CNT!"=="0" (
  echo [ERROR] No PhysicalDrive found in the scan output.
  echo   * Is the SSD plugged DIRECTLY into a motherboard M.2 slot?
  echo   * NOT inside the RTL9210 USB enclosure
  echo   * M.2 2230 may need a 2230-to-2280 adapter
  echo   * Does this PE have NVMe drivers? Try a Win10/11 64-bit PE.
  echo   * In Safe Mode some storage filter drivers are not loaded;
  echo     WinPE / Linux USB boot avoids that.
  goto DONE
)

set "DISKNO="
if "!CNT!"=="1" (
  for /f "tokens=1" %%N in ("!CANDS!") do set "DISKNO=%%N"
  echo Auto-selected the only candidate: PhysicalDrive!DISKNO!
  echo If that is NOT the 256GB Samsung, type anything but Y later.
  goto HAVEDISK
)
echo Several candidates:!CANDS!
echo Check the scan output above; pick the 256GB Samsung one.

:ASKPICK
set "PICK="
set /p "PICK=Type its number (digits only): "
if not defined PICK (
  echo [ERROR] Empty input. Cancelled.
  goto DONE
)
set "VALID="
for %%C in (!CANDS!) do if "%%C"=="!PICK!" set "VALID=1"
if not defined VALID (
  echo [ERROR] That number is not in the scan result. Cancelled.
  goto DONE
)
set "DISKNO=!PICK!"

:HAVEDISK
if not defined DISKNO goto DONE
echo Target: \\.\PhysicalDrive!DISKNO!
echo.

echo [3/5] Reading PSID ...
findstr /b /i "PSID=" "%~dp0PSID.txt" > "!PSID_FILE!" 2>nul
set "PSID="
for /f "usebackq tokens=1,* delims==" %%A in ("!PSID_FILE!") do (
  if not defined PSID set "PSID=%%B"
)
if defined PSID (
  set "PSID=!PSID: =!"
  set "PSID=!PSID:-=!"
)
if not defined PSID (
  echo PSID.txt is empty. Type the 32 chars from the SSD label now.
  set /p "PSID=PSID: "
  set "PSID=!PSID: =!"
  set "PSID=!PSID:-=!"
)
set "PSID=!PSID:a=A!"
set "PSID=!PSID:b=B!"
set "PSID=!PSID:c=C!"
set "PSID=!PSID:d=D!"
set "PSID=!PSID:e=E!"
set "PSID=!PSID:f=F!"
set "PSID=!PSID:g=G!"
set "PSID=!PSID:h=H!"
set "PSID=!PSID:i=I!"
set "PSID=!PSID:j=J!"
set "PSID=!PSID:k=K!"
set "PSID=!PSID:l=L!"
set "PSID=!PSID:m=M!"
set "PSID=!PSID:n=N!"
set "PSID=!PSID:o=O!"
set "PSID=!PSID:p=P!"
set "PSID=!PSID:q=Q!"
set "PSID=!PSID:r=R!"
set "PSID=!PSID:s=S!"
set "PSID=!PSID:t=T!"
set "PSID=!PSID:u=U!"
set "PSID=!PSID:v=V!"
set "PSID=!PSID:w=W!"
set "PSID=!PSID:x=X!"
set "PSID=!PSID:y=Y!"
set "PSID=!PSID:z=Z!"
echo !PSID!| findstr /r "^[A-Z0-9][A-Z0-9]*$" >nul
if errorlevel 1 (
  echo [ERROR] PSID must contain only A-Z and 0-9. Cancelled.
  goto DONE
)
echo PSID loaded: !PSID:~0,4! ... !PSID:~-4!
echo.

echo [4/5] Final confirmation
echo ============================================================
echo  Target : \\.\PhysicalDrive!DISKNO!
echo  PSID   : !PSID:~0,4! ... !PSID:~-4!
echo  Action : PSID Revert to factory default, ALL DATA ERASED
echo  CHECK  : 256GB Samsung ONLY. Any doubt - do not type Y.
echo ============================================================
set "OK="
set /p "OK=Type Y to proceed (anything else cancels): "
if /i "!OK!"=="Y" goto RUN
if /i "!OK!"=="YES" goto RUN
echo Cancelled, nothing changed.
goto DONE

:RUN
set "DEV=\\.\PhysicalDrive!DISKNO!"
if defined PSID_DRYRUN (
  echo [DRYRUN] Would run:
  echo   "%CLI%" --yesIreallywanttoERASEALLmydatausingthePSID !PSID! !DEV!
  goto DONE
)
echo.
echo [5/5] Running PSID Revert ...
"%CLI%" --yesIreallywanttoERASEALLmydatausingthePSID !PSID! !DEV!
set "RC=!ERRORLEVEL!"
echo Exit code: !RC!
if not "!RC!"=="0" (
  echo.
  echo If it reports an unknown option, try this equivalent form:
  echo   "%CLI%" --PSIDrevert !PSID! !DEV!
)
echo.
echo --- verify ---
"%CLI%" --query !DEV!
echo.
echo Done. Reboot, then initialise the disk (GPT + NTFS) and put it
echo back into the USB enclosure.

:DONE
echo.
echo Press any key to close this window.
pause >nul
endlocal
exit /b 0
