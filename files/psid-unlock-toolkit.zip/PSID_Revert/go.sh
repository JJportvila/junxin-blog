#!/bin/bash
# ------------------------------------------------------------------
# One-step PSID Revert: auto-detect disk, auto-read PSID, one Y to go.
# From a Linux Live USB:
#   sudo mount /dev/sda1 /mnt && sudo bash /mnt/PSID_Revert/go.sh
# All output is English: a Live tty has no CJK font support.
# ------------------------------------------------------------------
set -u
here="$(cd "$(dirname "$0")" && pwd)"

echo "============================================================"
echo " One-step PSID Revert  (Samsung PM9C1a / Dell OEM)"
echo " Destroys the encryption key and ALL data on the target disk."
echo "============================================================"
echo

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: root required. Run the command with sudo."
    exit 1
fi

# exFAT has no usable exec bit, so stage the ELF binaries in /tmp.
CLI=""
if cp "$here/sedutil-cli-linux" /tmp/sedutil-cli 2>/dev/null; then
    chmod 755 /tmp/sedutil-cli && CLI=/tmp/sedutil-cli
fi
OLD=""
if cp "$here/sedutil-cli-linux-legacy" /tmp/sedutil-cli-legacy 2>/dev/null; then
    chmod 755 /tmp/sedutil-cli-legacy && OLD=/tmp/sedutil-cli-legacy
fi
if [ -z "$CLI" ]; then
    echo "ERROR: sedutil-cli-linux missing. Copy the WHOLE PSID_Revert folder."
    exit 1
fi

if [ -w /sys/module/libata/parameters/allow_tpm ]; then
    echo 1 > /sys/module/libata/parameters/allow_tpm 2>/dev/null || true
fi

# ---- PSID: read from PSID.txt, fall back to one prompt ----
PSID=""
if [ -f "$here/PSID.txt" ]; then
    raw=$(grep -m1 '^PSID=' "$here/PSID.txt" | cut -d= -f2-)
    PSID=$(printf '%s' "$raw" | tr -d '[:space:]-' | tr '[:lower:]' '[:upper:]')
fi
if ! printf '%s' "$PSID" | grep -Eq '^[A-Z0-9]{20,40}$'; then
    echo "PSID.txt is empty or invalid. Type the 32 chars from the SSD label now."
    echo "(or edit PSID.txt on a Windows PC and run this again)"
    printf 'PSID: '
    read -r PSID
    PSID=$(printf '%s' "$PSID" | tr -d '[:space:]-' | tr '[:lower:]' '[:upper:]')
fi
if ! printf '%s' "$PSID" | grep -Eq '^[A-Z0-9]{20,40}$'; then
    echo "ERROR: invalid PSID. Cancelled."; exit 1
fi
# POSIX-safe masking: no bash substring expansion, so busybox/sh works too.
PSHOWN="$(printf '%s' "$PSID" | cut -c1-4) ... $(printf '%s' "$PSID" | sed 's/.*\(....\)$/\1/')"
echo "PSID loaded: $PSHOWN"

# ---- auto-detect the target NVMe disk ----
echo
echo "--- sedutil --scan ---"
scan=$("$CLI" --scan 2>&1)
printf '%s\n' "$scan"
echo
cands=$(printf '%s\n' "$scan" | awk '$1 ~ /^\/dev\/nvme[0-9]+$/ && $2 == 2 {print $1}')
if [ -z "$cands" ]; then
    echo "No OPAL 2 NVMe disk found. Check:"
    echo "  * SSD plugged DIRECTLY into a motherboard M.2 slot"
    echo "  * NOT inside the RTL9210 USB enclosure"
    echo "  * M.2 2230 may need a 2230-to-2280 adapter"
    echo "  * reseat the SSD and reboot the Live USB"
    exit 1
fi

n=$(printf '%s\n' "$cands" | wc -l)
if [ "$n" -eq 1 ]; then
    DEV="$cands"
    Ok="Auto-selected target: $DEV (the only OPAL 2 NVMe disk)"
    echo "$Ok"
else
    echo "Several OPAL 2 NVMe disks found - pick the 256GB Samsung one:"
    lsblk -o NAME,SIZE,TYPE,MODEL,MOUNTPOINT 2>/dev/null || true
    i=0
    for d in $cands; do i=$((i+1)); echo "  $i) $d"; done
    printf 'Number: '
    read -r pick
    DEV=$(printf '%s\n' "$cands" | sed -n "${pick}p")
    if [ -z "$DEV" ]; then echo "Cancelled, nothing changed."; exit 0; fi
fi

echo
echo "--- disks ---"
lsblk -o NAME,SIZE,TYPE,MODEL,MOUNTPOINT 2>/dev/null || true
echo

# ---- one single confirmation ----
echo "============================================================"
echo " Target : $DEV"
echo " PSID   : $PSHOWN"
echo " Action : PSID Revert -> factory default, ALL DATA ERASED"
echo "============================================================"
printf 'Type Y to proceed (anything else cancels): '
read -r ok
case "$ok" in
    Y|y) ;;
    *) echo "Cancelled, nothing changed."; exit 0 ;;
esac

echo
echo ">>> Running PSID Revert ..."
"$CLI" --yesIreallywanttoERASEALLmydatausingthePSID "$PSID" "$DEV"
rc=$?
if [ "$rc" -ne 0 ] && [ -n "$OLD" ]; then
    echo "Retrying with the legacy binary ..."
    "$OLD" --yesIreallywanttoERASEALLmydatausingthePSID "$PSID" "$DEV"
    rc=$?
fi

echo
echo "Exit code: $rc"
echo "--- verify ---"
"$CLI" --query "$DEV" 2>&1 | grep -Ei 'Locked|LockingEnabled|LockingSupported' || true
echo
echo "Done. Reboot, then in Windows run the desktop script"
echo "(GPT partition + NTFS format), or use diskpart."
echo
