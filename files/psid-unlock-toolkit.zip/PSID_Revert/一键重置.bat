@echo off
setlocal
title PSID Revert - Unlock SSD

rem Safe Mode: "net session" needs the Server service, which is OFF there.
rem Check the process token directly instead - no service needed at all.
if /i "%~1"=="ELEVATED" set "TRIED=1"

powershell.exe -NoProfile -Command "exit ([int](-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)))"
if not errorlevel 1 goto ADMIN_OK

if defined TRIED goto NOADMIN

echo.
echo [1/2] Need administrator rights for raw disk access.
echo       A UAC window will appear -- click YES.
echo       (Normal: sedutil must talk to the SSD directly.)
echo.
set "THIS=%~f0"
set "THISDIR=%~dp0"
powershell.exe -NoProfile -Command "try { Start-Process -FilePath $env:THIS -ArgumentList 'ELEVATED' -Verb RunAs -WorkingDirectory $env:THISDIR -ErrorAction Stop } catch { exit 1 }"
if errorlevel 1 goto NOADMIN
exit /b

:NOADMIN
echo.
echo [ERROR] Still not running as administrator.
echo.
echo   In Windows SAFE MODE this is common: the Server service is off and
echo   the Application Information service (UAC elevation) may be off too.
echo   net session is NOT a valid admin test in Safe Mode.
echo.
echo   Try one of these, in order:
echo     A) Log in with the built-in Administrator account, run this again.
echo     B) Double-click the PE*.bat in this folder (pure cmd, no UAC,
echo        no PowerShell, no Server service). It works in Safe Mode too.
echo     C) Boot from the USB into WinPE or Linux - most reliable.
echo.
echo   Nothing was changed.
echo.
pause
exit /b 1

:ADMIN_OK
cd /d "%~dp0"

if not exist "%~dp0run.ps1" (
  echo [ERROR] run.ps1 not found. Copy the WHOLE PSID_Revert folder.
  echo.
  pause
  exit /b 1
)
if not exist "%~dp0sedutil-cli.exe" (
  echo [ERROR] sedutil-cli.exe not found. Copy the WHOLE PSID_Revert folder.
  echo.
  pause
  exit /b 1
)

set "PS1=%~dp0run.ps1"
set "LOG=%~dp0last_run.log"

echo.
echo [2/2] Running as administrator. Full log will be saved to:
echo       %LOG%
echo       Keep this window open and read each prompt before typing.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { Start-Transcript -Path $env:LOG -Force | Out-Null } catch {}; & $env:PS1; try { Stop-Transcript | Out-Null } catch {}"

echo.
echo ============================================================
echo  Done. This window stays open until you press a key.
echo  Full output saved to: %LOG%
echo  If it still ends too fast, open that .log with Notepad and
echo  send it to me -- it records exactly where it stopped.
echo ============================================================
echo.
pause
exit /b 0
