﻿#Requires -Version 5.1
$ErrorActionPreference = 'Continue'
$exe = Join-Path $PSScriptRoot 'sedutil-cli.exe'

function Info($m) { Write-Host $m -ForegroundColor Cyan }
function Warn($m) { Write-Host $m -ForegroundColor Yellow }
function Ok($m)   { Write-Host $m -ForegroundColor Green }
function Fail($m) { Write-Host $m -ForegroundColor Red }

Write-Host ''
Write-Host '============================================================'
Write-Host '   PSID Revert - 解除 BIOS 硬盘密码锁'
Write-Host '   目标: 三星 PM9C1a 256GB (Dell OEM, DPN 03497H)'
Write-Host '============================================================'
Write-Host ''
Warn '本操作会永久销毁加密密钥和整盘数据，不可恢复。'
Write-Host '     (已确认盘内无重要数据)'
Write-Host ''

if (-not (Test-Path $exe)) {
    Fail '找不到 sedutil-cli.exe，请确认它与本脚本在同一目录。'
    Read-Host '按回车退出'
    exit 1
}

Info 'Step 1/5  扫描 TCG Opal 设备'
Write-Host ''
$scan = (& $exe --scan 2>&1 | Out-String)
Write-Host $scan

if ($scan -match 'proper authority|Try running as Administrator') {
    Fail '没有原始磁盘访问权限（需要管理员令牌）。'
    Write-Host '  普通模式：关闭窗口，右键「一键重置.bat」→ 以管理员身份运行。'
    Write-Host '  安全模式：UAC 提权常不可用，net session 也不能用来判权限。'
    Write-Host '            请用内置 Administrator 账户登录，或直接双击'
    Write-Host '            「PE专用_一键重置.bat」（纯 cmd，不依赖 UAC / PowerShell）。'
    Write-Host '            最稳妥的是从 U 盘启动 WinPE 或 Linux。'
    Read-Host '按回车退出'
    exit 1
}

$lines = @($scan -split "`r?`n")
$devLines = @($lines | Where-Object { $_ -match 'PhysicalDrive\d+' })

if ($devLines.Count -eq 0) {
    Fail '没有扫描到任何磁盘设备。'
    Write-Host ''
    Warn '若这块 SSD 是通过 USB 硬盘盒连接的，请注意:'
    Write-Host '  RTL9210 等 USB 桥接芯片通常不透传 TCG Opal 命令，'
    Write-Host '  工具会看不到盘或显示为 No，此时 PSID Revert 无法进行。'
    Write-Host ''
    Write-Host '  → 请把 SSD 从硬盘盒取出，直连主板 M.2 插槽后重新运行。'
    Write-Host '  → 该盘疑似 M.2 2230 短规格，台式机可能需 2230→2280 转接片。'
    Read-Host '按回车退出'
    exit 1
}

Info '扫描结果中的磁盘 (第 2 列 No = 未识别到 Opal 支持):'
Write-Host ''
$devLines | ForEach-Object { Write-Host ('   ' + $_.Trim()) }
Write-Host ''
Warn '请确认上面能看到那块 256GB 三星盘，且第 2 列不是 No。'
$go = Read-Host '能看到吗? (Y 继续 / N 查看连接方式说明)'
if ($go -notmatch '^[Yy]$') {
    Write-Host ''
    Warn 'USB 硬盘盒接法大概率不通。请改为:'
    Write-Host '  1. 把 SSD 从硬盘盒取出'
    Write-Host '  2. 直连电脑主板的 M.2 NVMe 插槽 (不要经过 USB 桥接)'
    Write-Host '  3. 量一下盘长: 约 30mm 是 M.2 2230，台式机需 2230→2280 转接片'
    Write-Host '  4. 重新运行本工具'
    Read-Host '按回车退出'
    exit 0
}

Info "`nStep 2/5  选择目标磁盘"

# 把 --scan 输出里出现的 PhysicalDrive 编号列出来，并对照 Windows 磁盘信息，
# 避免用户面对原始扫描输出不知道该填几。
$nums = @($devLines | ForEach-Object {
    if ($_ -match 'PhysicalDrive(\d+)') { [int]$Matches[1] }
} | Sort-Object -Unique)

Write-Host ''
Write-Host 'Step 1 扫描结果里出现的编号 (只填数字):'
foreach ($cand in $nums) {
    $cd = Get-Disk -Number $cand -ErrorAction SilentlyContinue
    if ($cd) {
        $sizeGB = [math]::Round($cd.Size / 1GB, 2)
        $flag = ''
        if ($cd.IsBoot -or $cd.IsSystem) {
            $flag = '  [系统/启动盘 - 不要选]'
        } elseif ($sizeGB -gt 200 -and $sizeGB -lt 300) {
            $flag = '  [约 256GB - 可能是目标盘]'
        }
        Write-Host ("   {0}  ->  {1} / {2} GB / {3}{4}" -f $cand, $cd.FriendlyName, $sizeGB, $cd.BusType, $flag)
    } else {
        Write-Host ("   {0}  ->  Windows 磁盘列表不可见 (锁定的盘常见此现象)" -f $cand)
    }
}
Write-Host ''

# 只有唯一候选看起来确实是那块 256GB 三星盘时才自动选定。
# 若唯一候选是一块可见的内置大容量盘，说明目标 SSD 没插好，
# 此时绝不自动选，避免把不可逆的 PSID Revert 打到内置盘上。
$autoPick = $false
if ($nums.Count -eq 1) {
    $cd = Get-Disk -Number $nums[0] -ErrorAction SilentlyContinue
    if (-not $cd) {
        # 被锁定的盘在 Windows 磁盘列表里常常不可见，且它是唯一候选
        $diskNo = [string]$nums[0]
        $autoPick = $true
        Ok "已自动选定唯一候选编号: $diskNo (磁盘列表不可见，锁定盘常见)"
    } else {
        $gb = [math]::Round($cd.Size / 1GB, 2)
        if ($gb -ge 200 -and $gb -lt 300) {
            $diskNo = [string]$nums[0]
            $autoPick = $true
            Ok "已自动选定唯一候选编号: $diskNo ($gb GB, 疑似目标三星 256GB 盘)"
        }
    }
}
if (-not $autoPick) {
    Write-Host ''
    Fail '未找到约 256GB 的目标盘，已停止自动选定以防误伤内置硬盘。'
    Write-Host '  请确认 SSD 已从 USB 硬盘盒取出，直连主板 M.2 NVMe 插槽。'
    Write-Host '  (隔着 RTL9210 USB 桥接，sedutil 看不到这块盘)'
    Write-Host '  若确认已直连且要手动指定，输入上面的编号；直接回车 = 安全取消。'
    Write-Host ''
    $diskNo = Read-Host '目标盘 PhysicalDrive 编号 (只填数字，回车取消)'
    if ([string]::IsNullOrWhiteSpace($diskNo)) {
        Warn '已取消，未做任何更改。'
        Read-Host '按回车退出'
        exit 0
    }
}
if ($diskNo -notmatch '^\d+$') {
    Fail '输入无效，已取消。'
    Read-Host '按回车退出'
    exit 1
}
$n = [int]$diskNo
if (-not ($devLines -match ("PhysicalDrive" + $n + "\b"))) {
    Fail "编号 $n 不在扫描结果中，为安全起见已取消。"
    Read-Host '按回车退出'
    exit 1
}

$d = Get-Disk -Number $n -ErrorAction SilentlyContinue
if ($d -and ($d.IsBoot -or $d.IsSystem)) {
    Fail "拒绝: PhysicalDrive$n 是系统/启动盘，不能操作。"
    Read-Host '按回车退出'
    exit 1
}
if ($d) {
    Info ("该编号在 Windows 中对应: {0} / {1} GB" -f $d.FriendlyName, [math]::Round($d.Size/1GB,2))
} else {
    Warn '该编号在 Windows 磁盘列表中不可见 —— 被锁定的盘常见此现象，请自行确认是目标盘。'
}

Info "`nStep 3/5  PSID"
$psidFile = Join-Path $PSScriptRoot 'PSID.txt'
$psid = ''
if (Test-Path $psidFile) {
    foreach ($line in (Get-Content $psidFile)) {
        if ($line -match '^PSID\s*=\s*(.+)$') {
            $psid = (($Matches[1] -replace '[\s\-]', '')).ToUpper()
            break
        }
    }
}
if ($psid -match '^[A-Z0-9]{20,40}$') {
    Ok ("已从 U 盘 PSID.txt 读取: " + $psid.Substring(0,4) + ' ... ' + $psid.Substring($psid.Length-4))
} else {
    Write-Host 'PSID 印在 SSD 标签上，两行连起来；注意区分 0/O、1/I、2/Z、5/S、8/B。'
    Write-Host '（也可以填进 U 盘的 PSID.txt，以后就不用再输）'
    $psid = (((Read-Host 'PSID').Trim()) -replace '[\s\-]', '').ToUpper()
}
if ($psid -notmatch '^[A-Z0-9]{20,40}$') {
    Fail 'PSID 格式不对: 应只含大写字母和数字，长度约 32 位。'
    Read-Host '按回车退出'
    exit 1
}

$device = '\\.\PhysicalDrive' + $n
$mask = $psid.Substring(0,4) + ' ... ' + $psid.Substring($psid.Length-4)
Warn "`nStep 4/5  最后确认"
Write-Host ("  目标设备 : {0}" -f $device)
Write-Host ("  PSID     : {0}" -f $mask)
Write-Host '  将执行   : --yesIreallywanttoERASEALLmydatausingthePSID'
Write-Host '  后果     : 销毁加密密钥 + 全部数据，盘回到出厂未初始化状态 (不可逆)'
Write-Host ''
$ok = Read-Host '确认请输入 Y (输别的即取消)'
if ($ok -notin @('Y','YES')) {
    Warn '已取消，未做任何更改。'
    Read-Host '按回车退出'
    exit 0
}

Info "`nStep 5/5  执行 PSID Revert"
Write-Host ''
$result = (& $exe --yesIreallywanttoERASEALLmydatausingthePSID $psid $device 2>&1 | Out-String)
Write-Host $result
Write-Host ("退出码: {0}" -f $LASTEXITCODE)
Write-Host ''
Info '请查看上面的输出，确认是否出现成功提示。'
Write-Host '验证: 重新插拔 / 重启后执行下面命令，不再显示锁定即成功:'
Write-Host ("  sedutil-cli.exe --query {0}" -f $device)
Write-Host ''
Write-Host '若报语法/参数错误，改用等价命令 (把 <PSID> 换成标签上的值):'
Write-Host ("  sedutil-cli.exe --PSIDrevert <PSID> {0}" -f $device)
Write-Host ''
Ok '解锁成功后的收尾:'
Write-Host '  1. 重新插拔 SSD 或重启，Windows 磁盘管理里应出现正常的 238GB 容量'
Write-Host '  2. 右键管理员运行桌面「修复移动硬盘.bat」，完成 GPT 分区 + NTFS 格式化'
Write-Host '  3. 装回硬盘盒即可正常使用'
Write-Host ''
Read-Host '按回车退出'
