#!/bin/bash
# ------------------------------------------------------------------
# PSID Revert helper for a locked TCG Opal NVMe SSD
# Boot path: Ventoy -> Ubuntu Live -> tty -> sudo -s -> bash this file
# All output is English on purpose: a Live tty has no CJK font support.
# ------------------------------------------------------------------
set -u
here="$(cd "$(dirname "$0")" && pwd)"

echo "============================================================"
echo " PSID Revert  (Samsung PM9C1a 256GB / Dell OEM DPN 03497H)"
echo " WARNING: destroys the encryption key and ALL DATA on the"
echo "          target disk. This cannot be undone."
echo "============================================================"
echo

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: root required. Run:  sudo -s   then re-run this script."
    exit 1
fi

# exFAT (Ventoy data partition) has no usable exec bit, so stage the
# ELF binaries in /tmp and run them from there.
CLI=""; CLI_OLD=""
if cp "$here/sedutil-cli-linux" /tmp/sedutil-cli 2>/dev/null; then
    chmod 755 /tmp/sedutil-cli && CLI=/tmp/sedutil-cli
fi
if cp "$here/sedutil-cli-linux-legacy" /tmp/sedutil-cli-legacy 2>/dev/null; then
    chmod 755 /tmp/sedutil-cli-legacy && CLI_OLD=/tmp/sedutil-cli-legacy
fi
if [ -z "$CLI" ]; then
    echo "ERROR: sedutil-cli-linux is missing next to this script."
    echo "       Copy the WHOLE PSID_Revert folder to the USB drive."
    exit 1
fi

# Needed on some ATA setups; harmless on pure NVMe.
if [ -w /sys/module/libata/parameters/allow_tpm ]; then
    echo 1 > /sys/module/libata/parameters/allow_tpm 2>/dev/null || true
fi

echo "--- block devices ---"
lsblk -o NAME,SIZE,TYPE,MODEL,MOUNTPOINT 2>/dev/null || true
echo
echo "--- NVMe controller nodes ---"
nvme_nodes=$(ls -d /dev/nvme[0-9] 2>/dev/null | sort)
if [ -z "$nvme_nodes" ]; then
    echo "  (none found)"
    echo
    echo "No NVMe controller visible. Check:"
    echo "  * SSD is plugged DIRECTLY into a motherboard M.2 slot"
    echo "  * it is NOT inside the RTL9210 USB enclosure"
    echo "  * M.2 2230 usually needs a 2230-to-2280 adapter on desktop boards"
    echo "  * reseat the SSD and reboot the Live USB"
    exit 1
fi
printf '  %s\n' $nvme_nodes
echo

echo "--- sedutil --scan (2nd column must be 2 = OPAL 2) ---"
scan=$("$CLI" --scan 2>&1); rc=$?
printf '%s\n' "$scan"
echo
good=$(printf '%s\n' "$scan" | awk '$1 ~ /^\/dev\/nvme[0-9]+$/ && $2 == 2 {print $1}')
if [ -z "$good" ]; then
    echo "WARNING: no NVMe disk reported as OPAL 2."
    echo "  If the SSD sits behind a USB bridge, Opal commands are NOT passed through."
    echo "  Plug it into a motherboard M.2 slot and reboot. Do NOT continue if unsure."
fi
echo
printf 'Target device [/dev/nvme0] (q = quit): '
read -r DEV
case "$DEV" in
    q|Q|"") echo "Cancelled, nothing changed."; exit 0 ;;
esac
if ! printf '%s' "$DEV" | grep -Eq '^/dev/nvme[0-9]+$'; then
    echo "ERROR: expected a controller node like /dev/nvme0 (NOT /dev/nvme0n1)."
    exit 1
fi
if [ ! -e "$DEV" ]; then
    echo "ERROR: $DEV does not exist."; exit 1
fi

echo
echo "--- PSID (printed on the SSD label, two lines joined) ---"
echo "    A-Z and 0-9 only, no spaces or dashes."
echo "    watch out: 0/O  1/I  2/Z  5/S  8/B"
printf 'PSID: '
read -r PSID
PSID=$(printf '%s' "$PSID" | tr -d ' -' | tr '[:lower:]' '[:upper:]')
if ! printf '%s' "$PSID" | grep -Eq '^[A-Z0-9]{20,40}$'; then
    echo "ERROR: PSID looks wrong (need 20-40 chars of A-Z / 0-9). Cancelled."
    exit 1
fi
mask="${PSID:0:4} ... ${PSID: -4}"

echo
echo "============================================================"
echo " Target : $DEV"
echo " PSID   : $mask"
echo " Action : PSID Revert -> factory default, ALL DATA ERASED"
echo "============================================================"
printf 'Type YES (uppercase) to proceed: '
read -r ok
if [ "$ok" != "YES" ]; then
    echo "Cancelled, nothing changed."; exit 0
fi

echo
echo ">>> Running PSID Revert ..."
"$CLI" --yesIreallywanttoERASEALLmydatausingthePSID "$PSID" "$DEV"
rc=$?
echo
if [ "$rc" -eq 0 ]; then
    echo "Finished with exit code 0. Look for a success message above."
else
    echo "Exit code $rc."
    if [ -n "$CLI_OLD" ]; then
        echo "Retrying with the legacy binary ..."
        "$CLI_OLD" --yesIreallywanttoERASEALLmydatausingthePSID "$PSID" "$DEV"
        echo "(legacy exit code $?)"
    fi
fi
echo
echo "Verify:  $CLI --query $DEV"
echo "         Locked = N, LockingEnabled = N   means unlocked."
echo
echo "Next: reboot (or 'nvme reset $DEV'), then in Windows run"
echo "      Windows desktop script (right-click -> Run as administrator)"
echo "      to create the GPT partition + NTFS format."
echo
