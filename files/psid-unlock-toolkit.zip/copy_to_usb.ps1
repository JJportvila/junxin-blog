﻿#Requires -Version 5.1
param(
    [switch]$ScanOnly,
    [string]$Drive,
    [switch]$Yes
)

$ErrorActionPreference = 'Stop'
$sourceDir = Join-Path $PSScriptRoot 'PSID_Revert'

function Info($m) { Write-Host $m -ForegroundColor Cyan }
function Warn($m) { Write-Host $m -ForegroundColor Yellow }
function Ok($m)   { Write-Host $m -ForegroundColor Green }
function Fail($m) { Write-Host $m -ForegroundColor Red }
function Hold()   { if (-not $Yes) { Write-Host ''; Read-Host '按回车退出' } }

Write-Host ''
Write-Host '============================================================'
Write-Host '   把 PSID_Revert 工具文件夹写入 U 盘'
Write-Host '   不会格式化 U 盘，只复制文件'
Write-Host '============================================================'
Write-Host ''

if (-not (Test-Path -LiteralPath $sourceDir -PathType Container)) {
    Fail "找不到工具目录: $sourceDir"
    Write-Host '请确认本脚本与 PSID_Revert 文件夹放在同一目录。'
    Hold; exit 1
}

$files = @(Get-ChildItem -LiteralPath $sourceDir -File)
Info ("待复制文件 ({0} 个):" -f $files.Count)
$files | ForEach-Object { Write-Host ("   {0}   ({1} bytes)" -f $_.Name, $_.Length) }
Write-Host ''

# 列出所有可移动磁盘 (DriveType=2)
$usb = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=2' | Sort-Object DeviceID)
Write-Host '检测到的可移动磁盘:'
if ($usb.Count -eq 0) {
    Warn '   (未检测到 U 盘 — 请先插上 U 盘，再重新运行本脚本)'
} else {
    foreach ($d in $usb) {
        $size = 0; $free = 0
        if ($d.Size)      { $size = [math]::Round($d.Size / 1GB, 2) }
        if ($d.FreeSpace) { $free = [math]::Round($d.FreeSpace / 1GB, 2) }
        $label = if ($d.VolumeName) { $d.VolumeName } else { '(无卷标)' }
        Write-Host ("   {0,-4} {1,-16} {2,8} GB   可用 {3,8} GB   [{4}]" -f $d.DeviceID, $label, $size, $free, $d.FileSystem)
    }
}
Write-Host ''

if ($ScanOnly) {
    Info '仅扫描模式 (-ScanOnly)，未做任何更改。'
    exit 0
}

if ($Drive) {
    $letter = $Drive
    Info "已指定目标盘符: $letter (非交互模式)"
} else {
    $letter = (Read-Host '请输入 U 盘盘符 (例如 E: ，直接回车取消)').Trim()
}
if ([string]::IsNullOrWhiteSpace($letter)) {
    Warn '已取消，未做任何更改。'; Hold; exit 0
}
if ($letter -match '^[A-Za-z]:?$') { $letter = $letter.Substring(0,1).ToUpper() + ':' }
if ($letter -notmatch '^[A-Z]:$') {
    Fail "盘符格式不对: $letter  (应类似 E: )"; Warn '未做任何更改。'; Hold; exit 0
}

# 安全校验：只允许写入可移动磁盘，防止误写内置硬盘
$target = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$letter'" -ErrorAction SilentlyContinue
if (-not $target) {
    Fail "系统中找不到盘符 $letter"; Warn '未做任何更改。'; Hold; exit 0
}
if ($target.DriveType -ne 2) {
    Fail "拒绝写入: $letter 不是可移动磁盘 (DriveType=$($target.DriveType))。"
    Write-Host '         为防误操作内置硬盘，本脚本只接受 U 盘。'
    Warn '未做任何更改。'; Hold; exit 0
}

$dest = Join-Path ($letter + '\') 'PSID_Revert'
Write-Host ''
Write-Host "源目录  : $sourceDir"
Write-Host "目标路径: $dest"
Write-Host ''
Warn '目标文件夹若已存在同名文件会被覆盖；不会删除 U 盘上的其他文件。'
$confirm = if ($Yes) { 'Y' } else { (Read-Host '确认复制请输入 Y').Trim() }
if ($confirm -notin @('Y','y')) {
    Warn '已取消，未做任何更改。'; Hold; exit 0
}

try {
    if (-not (Test-Path -LiteralPath $dest)) {
        New-Item -ItemType Directory -Path $dest -Force -ErrorAction Stop | Out-Null
    }
    foreach ($f in $files) {
        $dstFile = Join-Path $dest $f.Name
        # Never wipe a PSID the user already typed on the USB stick.
        if ($f.Name -eq 'PSID.txt' -and (Test-Path -LiteralPath $dstFile)) {
            $filled = @(Get-Content -LiteralPath $dstFile -ErrorAction SilentlyContinue |
                        Where-Object { $_ -match '^PSID\s*=\s*\S' })
            if ($filled.Count -gt 0) {
                Warn '  PSID.txt: USB copy already has a PSID -> kept, not overwritten.'
                continue
            }
        }
        Copy-Item -LiteralPath $f.FullName -Destination $dstFile -Force -ErrorAction Stop
    }
    # 顺带把根目录的 Linux 说明放到 U 盘根目录，方便开机前一目了然
    foreach ($doc in @('LINUX启动步骤.txt','启动不了_排错.txt','简单版说明.txt','先看我.txt','PE说明.txt')) {
        $srcDoc = Join-Path $PSScriptRoot $doc
        if (Test-Path -LiteralPath $srcDoc) {
            Copy-Item -LiteralPath $srcDoc -Destination (Join-Path ($letter + '\') $doc) -Force -ErrorAction Stop
        }
    }
} catch {
    Fail ("复制失败: " + $_.Exception.Message)
    Write-Host '请检查 U 盘是否写保护、空间是否充足、是否被安全软件拦截。'
    Hold; exit 1
}

# 逐个校验文件确实落地
$missing = @($files | Where-Object { -not (Test-Path -LiteralPath (Join-Path $dest $_.Name)) })
if ($missing.Count -gt 0) {
    Fail ("以下文件未复制成功: " + ($missing.Name -join ', '))
    Hold; exit 1
}

Write-Host ''
Ok ("完成! 已复制 {0} 个文件到 {1}" -f $files.Count, $dest)
Write-Host ''
Write-Host '============================================================'
Write-Host '  下一步: 把 U 盘插到目标电脑，开机从 U 盘启动 (UEFI: Ventoy)'
Write-Host ''
Write-Host '  先做一次: 把标签上的 PSID 粘进 PSID_Revert\PSID.txt 保存'
Write-Host ''
Write-Host '  [能进 Windows 系统] 最省事: 双击 PSID_Revert\一键重置.bat'
Write-Host '    → 弹 UAC 点「是」自动提权，全程输出存 last_run.log'
Write-Host ''
Write-Host '  [本机没有系统盘] 只走 Linux 路线，照「LINUX启动步骤.txt」做:'
Write-Host '    开机选 UEFI: Ventoy → Ubuntu ISO → Ctrl+Alt+F2 → 粘 1 行:'
Write-Host '    sudo mount LABEL=Ventoy /mnt && sudo bash /mnt/PSID_Revert/go.sh'
Write-Host '    自动选盘 + 自动读 PSID，只看一眼摘要输 Y'
Write-Host '    启动不了看「启动不了_排错.txt」'
Write-Host ''
Warn '  重要: 这块 SSD 必须直连主板 M.2 插槽，'
Write-Host '        隔着 RTL9210 USB 硬盘盒无法完成 PSID Revert。'
Write-Host '============================================================'
Hold
exit 0
